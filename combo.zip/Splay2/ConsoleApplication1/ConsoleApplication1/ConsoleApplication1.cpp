#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct Lab04
{
	int klucz;
	struct Lab04 *left;
	struct Lab04 *right;
	char tab[16];
} drzewo;

//------------------------------------------------------------------------------------------------
drzewo* Splay(drzewo *root, int key)
{
	drzewo *x, *y, *parent, *grandparent, *child, *current, N, *l, *r;

	parent = NULL;
	grandparent = NULL;
	child = NULL;
	current = NULL;
	y = NULL;
	x = root;
	current = root;
	parent = NULL;
	grandparent = NULL;

	if (root == NULL) return root;
	N.left = N.right = NULL;
	l = &N;
	r = &N;

	for (;;) {
		if (key < root->klucz) {
			if (root->left == NULL) break;
			if (key < root->left->klucz) {
				y = root->left;                           /* rotate right */
				root->left = y->right;
				y->right = root;
				root = y;
				if (root->left == NULL) break;
			}
			r->left = root;                               /* link right */
			r = root;
			root = root->left;
		}
		else if (key > root->klucz) {
			if (root->right == NULL) break;
			if (key > root->right->klucz) {
				y = root->right;                          /* rotate left */
				root->right = y->left;
				y->left = root;
				root = y;
				if (root->right == NULL) break;
			}
			l->right = root;                              /* link left */
			l = root;
			root = root->right;
		}
		else {
			break;
		}
	}
	l->right = root->left;                                /* assemble */
	r->left = root->right;
	root->left = N.right;
	root->right = N.left;
	return root;



}
//szukaj
void szukaj(drzewo **root, int key)
{
	
	if (*root == NULL)
	{
		printf("Nie znaleziono wezla o kluczu %d - drzewo puste\n", key);
		return;
	}
	*root = Splay(*root, key);
	drzewo *pom;
	pom = *root;
	while (pom != NULL)
	{
		if (pom->klucz == key)
		{
			printf("W drzewie znajduje sie wezel o kluczu %d\n", pom->klucz);
			return;
		}
		if (pom->klucz < key)
			pom = pom->right;
		else
			pom = pom->left;
	}
	printf("W drzewie nie ma wezla o kluczu %d\n", key);

	return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
//stos
#define Max 100000
drzewo *stack[Max];
drzewo *stack2[Max];
int top, top2, X;


//------------------------------------------------------------------------------------------------
//inorder
void inorder(drzewo *root)
{
	printf("-----------------------Inorder------------------------\n");
	if (root == NULL)
	{
		printf("Lista pusta\n");
		return;
	}
	top = 0;
	drzewo *pom;
	pom = root;
	while (pom != NULL)
	{
		while (pom != NULL)
		{
			if (pom->right != NULL)
				stack[top++] = pom->right;
			stack[top++] = pom;
			pom = pom->left;
		}
		pom = stack[--top];
		while (top != 0 && pom->right == NULL)
		{
			printf("%d\n", pom->klucz);
			pom = stack[--top];
		}
		printf("%d\n", pom->klucz);
		if (top != 0)
			pom = stack[--top];
		else
			pom = NULL;
	}
	return;
}

//------------------------------------------------------------------------------------------------
//postorder

void usun_wezel(drzewo **root, int key)
{
	if (*root == NULL)
	{
		printf("Nie usunieto wezla o kluczu %d - drzewo puste\n", key);
		return;
	}
	*root = Splay(*root, key);
	drzewo *parent, *pom;
	pom = *root;
	parent = NULL;

	while ((pom != NULL) && (pom->klucz != key))
	{
		parent = pom;
		if (pom->klucz < key)
			pom = pom->right;
		else
			pom = pom->left;
	}

	if (pom == NULL)
	{
		printf("Nie usunieto wezla o kluczu %d - nie jest wezlem drzewa\n", key);
		return;
	}

	if (pom->left == NULL && pom->right == NULL) //jest lisciem
	{
		if (pom == *root)
		{
			*root = NULL;
			printf("Usunieto wezel o kluczu %d\n", pom->klucz);
			free(*root);
			return;
		}

		if (parent->right == pom)
			parent->right = NULL;
		else
			parent->left = NULL;

		printf("Usunieto wezel o kluczu %d\n", pom->klucz);
		free(pom);
		return;
	}

	if (pom->right == NULL) //ma tylko lewe poddrzewo
	{
		if (pom == *root)
		{
			*root = (*root)->left;
			printf("Usunieto wezel o kluczu %d\n", pom->klucz);
			free(*root);
			return;
		}

		if (parent->right == pom)
			parent->right = pom->left;
		else
			parent->left = pom->left;

		printf("Usunieto wezel o kluczu %d\n", pom->klucz);
		free(pom);
		return;
	}

	if (pom->left == NULL) //ma tylko prawe poddrzewo
	{
		if (pom == *root)
		{
			*root = (*root)->right;
			printf("Usunieto wezel o kluczu %d\n", pom->klucz);
			free(*root);
			return;
		}

		if (parent->left == pom)
			parent->left = pom->right;
		else
			parent->right = pom->right;

		printf("Usunieto wezel o kluczu %d\n", pom->klucz);
		free(pom);
		return;
	}

	//ma oba poddrzewa  	  
	drzewo *tmp, *prevtmp;
	prevtmp = pom;

	tmp = pom->right;
	while (tmp->left != NULL) //szukanie nastepnika
	{
		prevtmp = tmp;
		tmp = tmp->left;
	}

	if (pom == *root) //usuwane wezel jest korzeniem
	{
		if (tmp == pom->right) //nastepnikiem jest potomek korzenia
		{
			tmp->left = pom->left;
			*root = tmp;
		}
		else
		{
			prevtmp->left = tmp->right;

			tmp->left = (*root)->left;
			tmp->right = (*root)->right;
			*root = tmp;

		}
		printf("Usunieto wezel o kluczu %d\n", pom->klucz);
		free(pom);
		return;
	}

	if (tmp == pom->right) //nastepnikem jest prawy potomek
	{
		if (parent->right == pom)
		{
			parent->right = pom->right;
			parent->right->left = pom->left;
		}
		else
		{
			parent->left = pom->right;
			parent->left->left = pom->left;
		}
	}
	else
	{
		prevtmp->left = tmp->right;

		tmp->left = pom->left;
		tmp->right = pom->right;

		if (parent->right == pom)
			parent->right = tmp;
		else
			parent->left = tmp;
	}
	printf("Usunieto wezel o kluczu %d\n", pom->klucz);
	free(pom);
	return;

}

//------------------------------------------------------------------------------------------------
//utworzenie nowego wezla
drzewo* dodaj(int key)
{
	drzewo *nowy = (drzewo*)malloc(sizeof(drzewo));

	nowy->klucz = key;
	nowy->left = NULL;
	nowy->right = NULL;
	int i;
	for (i = 0; i < 16; i++)
		nowy->tab[i] = rand() % 128;

	return nowy;
}


//------------------------------------------------------------------------------------------------
//wstawinie nowego wezla do drzewa
void wstaw(drzewo **root, int key)
{
	drzewo *pom, *parent;

	if (*root == NULL)
	{
		*root = dodaj(key);
		return;
	}

	parent = NULL;
	pom = *root;
	while (pom != NULL)
	{
		if (pom->klucz == key)
		{
			key++;
			//		printf("W drzewie juz znajduje sie wezel o kluczu %d\n", key);
	//		X--;
		//	return;
		}
		parent = pom;
		if (pom->klucz > key)
			pom = pom->left;
		else
			pom = pom->right;
	}

	if (parent->klucz > key)
		parent->left = dodaj(key);
	else parent->right = dodaj(key);
	*root = Splay(*root, key);
	return;
}

//------------------------------------------------------------------------------------------------
//rotacja w prawo
void rotacja_prawo(drzewo **root, drzewo **grandfather, drzewo **parent, drzewo **child)
{
	drzewo *tmp;
	if (*grandfather != NULL)
	{
		if ((*grandfather)->right == (*parent))
			(*grandfather)->right = (*child);
		else
			(*grandfather)->left = *child;
	}
	else
		*root = *child;

	tmp = (*child)->right;
	(*child)->right = *parent;
	(*parent)->left = tmp;

	return;
}

//------------------------------------------------------------------------------------------------
//przekszta�cenie w list� liniow�
void drzewo_liniowe(drzewo **root)
{
	drzewo *grandfather, *tmp, *pom;
	grandfather = NULL;
	tmp = *root;
	while (tmp != NULL)
	{
		if (tmp->left != NULL)
		{
			pom = tmp->left;
			rotacja_prawo(root, &grandfather, &tmp, &pom);
			tmp = pom;
		}
		else
		{
			grandfather = tmp;
			tmp = tmp->right;
		}
	}
}


//------------------------------------------------------------------------------------------------
//rotacja w lewo
void rotacja_lewo(drzewo **root, drzewo **grandfather, drzewo **parent, drzewo **child)
{
	drzewo *tmp;
	if (*grandfather != NULL)
	{
		if ((*grandfather)->right == (*parent))
			(*grandfather)->right = (*child);
		else
			(*grandfather)->left = *child;
	}
	else
		*root = *child;

	tmp = (*child)->left;
	(*child)->left = *parent;
	(*parent)->right = tmp;

	return;
}

//------------------------------------------------------------------------------------------------
//wywa�enie
void wywazenie(drzewo **root, int N)
{
	drzewo *grandfather, *tmp, *pom;
	int i, m = 1;
	grandfather = NULL;
	tmp = *root;
	while (m <= N)
		m = 2 * m + 1;
	m = m / 2;
	for (i = 0; i < (N - m); i++)
	{
		pom = tmp->right;
		if (pom != NULL)
		{
			rotacja_lewo(root, &grandfather, &tmp, &pom);
			grandfather = pom;
			tmp = pom->right;
		}
	}
	while (m > 1)
	{
		m = m / 2;
		grandfather = NULL;
		tmp = *root;
		for (i = 0; i < m; i++)
		{
			pom = tmp->right;
			rotacja_lewo(root, &grandfather, &tmp, &pom);
			grandfather = pom;
			tmp = pom->right;
		}
	}
	return;
}

//------------------------------------------------------------------------------------------------
//wysokosc drzewa
int wysokosc(drzewo *root)
{
	if (root == NULL)
		return 0;
	else
	{
		drzewo *pom;
		pom = root;

		int lh = wysokosc(pom->left);
		int rh = wysokosc(pom->right);

		if (lh > rh)
			return(lh + 1);
		else
			return(rh + 1);
	}
}

//------------------------------------------------------------------------------------------------
//postorder
void postorder(drzewo *root)
{
	printf("-----------------------Postorder-----------------------\n");
	if (root == NULL)
	{
		printf("Lista pusta\n");
		return;
	}
	top = 0;
	drzewo *pom;
	pom = root;
	top2 = 0;

	stack[top++] = root;
	while (top != 0)
	{
		pom = stack[--top];
		stack2[top2++] = pom;
		if (pom->left != NULL)
			stack[top++] = pom->left;
		if (pom->right != NULL)
			stack[top++] = pom->right;
	}
	while (top2 != 0)
	{
		pom = stack2[--top2];
		printf("%d\n", pom->klucz);
	}
	return;

}

//------------------------------------------------------------------------------------------------
//preorder
void preorder(drzewo *root)
{
	printf("-----------------------Preorder-----------------------\n");
	if (root == NULL)
	{
		printf("Lista pusta\n");
		return;
	}
	top = 0;
	drzewo *pom;
	pom = root;
	if (pom != NULL)
	{
		stack[top++] = pom;
		while (top != 0)
		{
			pom = stack[--top];
			printf("%d\n", pom->klucz);
			if (pom->right != NULL)
				stack[top++] = pom->right;
			if (pom->left != NULL)
				stack[top++] = pom->left;
		}
	}
	return;
}

//------------------------------------------------------------------------------------------------
//dodaj drzewo
void wstaw_drzewo(drzewo **root, int X)
{
	int i, key;
	for (i = 0; i < X; i++)
	{
		key = (rand() << rand() % 16) % 30000 + 25;
		//	key = rand()%100;
		wstaw(root, key);
	}
}


//------------------------------------------------------------------------------------------------
//Splay

/////////////////////////////////////////////////////////////////////////////////////
//inicjaizacja
drzewo *init()
{
	drzewo *root;
	root = (drzewo*)malloc(sizeof(drzewo));
	root = NULL;
	return root;
}

int main(int argc, char *argv[])
{
	clock_t begin, end;
	double time_spent;
	begin = clock();
	FILE *fp;
	fopen_s(&fp, "inlab05.txt", "r");
	int X1, K1, K2, K3;
	fscanf_s(fp, "%d %d %d %d", &X1, &K1, &K2, &K3);
	
	
	drzewo *root = init();
	wstaw_drzewo(&root, X1);
	inorder(root);
	preorder(root);
	wstaw(&root, K1);
	preorder(root);
	wstaw(&root, K2);
	preorder(root);
	szukaj(&root, K3);
	preorder(root);
	usun_wezel(&root, K2);
	preorder(root);
	inorder(root);
	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("\nCzas realizacji programu: %f", time_spent);
	/*FILE* fp = fopen("inlab04.txt", "r");
	if (fp == NULL)
		return -1;
	fscanf(fp, "%d %d", &X1, &X2);
	fclose(fp);

	srand(time(NULL));

	drzewo *root = init();
	X = X1;
	printf("Pierwsze drzewo:\n");
	wstaw_drzewo(&root, X1);

	
	printf("wysokosc drzewa przed wywazeniem %d\n", wysokosc(root));
	drzewo_liniowe(&root);
	wywazenie(&root, X);

	printf("wysokosc drzewa po wywazeniu %d\n", wysokosc(root));
	usun(&root);


	root = init();
	X = X2;
	printf("\nDrugie drzewo:\n");
	wstaw_drzewo(&root, X2);

	printf("wysokosc drzewa przed wywazeniem %d\n", wysokosc(root));
	drzewo_liniowe(&root);
	wywazenie(&root, X);

	printf("wysokosc drzewa po wywazeniu %d\n", wysokosc(root));
	usun(&root);

	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	printf("\nCzas realizacji programu: %f", time_spent);
	*/
	system("PAUSE>NULL");
	return 0;
}
