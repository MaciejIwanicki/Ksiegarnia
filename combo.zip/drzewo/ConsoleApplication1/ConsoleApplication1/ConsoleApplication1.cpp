// ConsoleApplication1.cpp : Defines the entry point for the console application.


#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

struct node
{
	int key;
	struct node *left;
	struct node *right;
	char tab[100];
};


int counter;


void Preorder (struct node *root)
{
	
	if(root == NULL) return;
	printf("%d\t",root->key);
	printf("%d",counter++);
	printf("\n");
	Preorder(root->left);
	Preorder(root->right);
	
	
}
void Inorder (struct node *root)
{
	
	if (root == NULL) return;
	Inorder(root->left);
	printf("%d\t",root->key);
	printf("%d",counter++);
	printf("\n");
	Inorder(root->right);
	
	
}
void Postorder(struct node *root)
{
	
	if(root == NULL) return;
	Preorder(root->left);
	Preorder(root->right);
	printf("%d\t",root->key);
	printf("%d",counter++);
	printf("\n");
	
}
void Find(struct node *root, int data)
{
	bool TEST = false;
	struct node *p;
	p = root;
	if( p == NULL)
		printf("drzewo jest puste \n");
	else
	{
	while((p!=NULL ) && (!TEST))
	{
		if(p->key == data)
			TEST = true;
		else if (p->key <data)
			p=p->right;	
		else
		p=p->left;
	}


	}
	if(TEST == true)
		printf("Znaleziono, wartosc pola to: %d \n",p->key);
	else
		printf("Brak pola o podanej wartosci \n");
	
}

int insert(struct node **root, int key) //zwr�cenie warto�ci -1 oznacza b��d
{
	struct node *new_node = (struct node*) malloc(sizeof(struct node));
	struct node *p, *parent;

new_node->left=NULL;
new_node->right=NULL;
new_node->key=key;

for (int i = 0; i < 100; i++)
{
	new_node->tab[i] = ( char )( rand() % 24 ) + 65;
}
parent=NULL;
p=*root;
while(p!=NULL)
{
if(p->key == key)
	{
		return (-1);
	printf("W drzewie istnieje element o podanej wartosci \n"); //w drzewie jest ju� element z �key�
	}
	parent=p;

	if(p->key > key)
	{
		p = p->left;
	}
	else
	{
		p = p->right;
	}
}
if(*root == NULL)
	 
		*root = new_node;
	

else if(parent->key > key)
	{
	parent->left = new_node;

	}	 
else
	{
	 parent->right = new_node;
	}


return(0);
}
int Insert_M(struct node **root, int x)
{
		
	
		struct node *p, *parent, *new_node;
	
		int value = 0;
		
		
	for(int i=0; i<x; i++)
	{
		 new_node = (struct node*) malloc(sizeof(struct node));
		
	value = rand()%19000 +11;
	new_node->left=NULL;
	new_node->right=NULL;
	
	for (int j = 0; j < 100; j++)
	{
		new_node->tab[j] = ( rand() % 24 ) + 65;
	}	
	
	new_node->key=value;
	parent=NULL;
	p=*root;
while(p!=NULL)
{
	if(p->key == value)
	{
		return (-1);
	printf("W drzewie istnieje element o podanej wartosci \n"); //w drzewie jest ju� element z �key�
	}
	parent=p;

	if(p->key > value)
	{
		p = p->left;
	}
	else
	{
		p = p->right;
	}
}
if(*root == NULL)
	 
		*root = new_node;
	

else if(parent->key > value)
	{
	parent->left = new_node;

	}	 
else
	{
	 parent->right = new_node;
	}
	value = 0;

	
	}
	

	
	return 0;
	
}

void Del ( struct node **root,int key)
{
    struct node *parent, *p, *child, *preparent, *grandchild;
 
    parent=NULL;
	p=*root;
 
	
	while((p!=NULL)&&(p->key!=key))
    {
        parent=p;
		if(p->key>key) p=p->left;
        else p=p->right;
    }
 
    if(p==NULL) printf("\nW drzewie nie ma wezla o danym kluczu.");
 
    else
    {
 
    if((p->left==NULL)&&(p->right==NULL))       //Jesli szukany wezel jest lisciem
    {
        if(p==(*root))
        {
            free(root);
            exit(0);
        }
        if(parent->right==p)
        {
            parent->right=NULL;
            free(p);
        }
        else
        {
            parent->left=NULL;
            free(p);
        }
    }
 
    else if(p->right==NULL)      //Jesli usuwany wezel ma tylko lewe poddrzewo
    {
        if(p==(*root))
        {
            p=(*root)->left;
            (*root)->key=p->key;
            (*root)->left=p->left;
            (*root)->right=p->right;
            free(p);
        }
        else if(parent->right==p)
        {
            parent->right=p->left;
            free(p);
        }
        else
        {
            parent->left=p->left;
            free(p);
        }
    }
 
    else if(p->left==NULL)        //Jesli usuwany wezel ma tylko prawe poddrzewo
    {
        if(p==(*root))
        {
            p=(*root)->right;
            (*root)->key=p->key;
            (*root)->right=p->right;
            (*root)->left=p->left;
            free(p);
        }
        else if(parent->right==p)
        {
            parent->right=p->right;
            free(p);
        }
        else
        {
            parent->left=p->right;
            free(p);
        }
    }
 
    else             //Usuwany ma dwa poddrzewa
    {
 
        preparent=p;
        child=p->left;
        while(child->right!=NULL)
        {
            preparent=child;
            child=child->right;
        }
 
        if(child==p->left)     //poprzednik jest lewym potomkiem usuwanego wezla
        {
            if(p==(*root))
            {
                p=(*root)->left;
                (*root)->key=p->key;
                (*root)->left=p->left;
                free(p);
            }
            else if(parent->right==p)
            {
                parent->right=child;
                child->right=p->right;
                free(p);
            }
            else
            {
                parent->left=child;
                child->right=p->right;
                free(p);
            }
        }
 
        else           //poprzednik jest pra potomkiem usuwanego wezla
        {
            grandchild=child->left;     //ewentualny potomek poprzednika
 
            if(preparent->right==child) preparent->right=grandchild;
            else preparent->left=grandchild;
 
            if(p==(*root))
            {
                (*root)->key=child->key;
                free(child);
            }
 
            else
            {
                child->left=p->left;
                child->right=p->right;
 
                if(parent->right==p)
                {
                    parent->right=child;
                    free(p);
                }
                else
                {
                    parent->left=child;
                    free(p);
                }
            }
        }
    }
    }
 
}
struct node *Init(struct node **root_ptr)
{
	struct node *root;
	root =( *root_ptr);
	root = NULL;
	return root;
	free(root);
}

int _tmain(int argc, _TCHAR* argv[])
{
	srand( time( NULL ) );
	int c_Pr=0,c_In=0,X,k1,k2,k3,k4;

	

	FILE *fp;
	fopen_s(&fp,"inlab03.txt", "r");
	fscanf_s(fp,"%d %d %d %d %d",&X,&k1,&k2,&k3,&k4);
	clock_t begin, end;
	double time_spent;
	begin = clock(); 
	struct node *root_ptr;
	root_ptr=Init(&root_ptr);
	
	Del(&root_ptr,k1);
	insert(&root_ptr,k1);
	Insert_M(&root_ptr, X);
	printf("\nWyswietlanie  w trybie Inorder\n");
	Inorder(root_ptr);
	counter = 1 ;
	printf("\nWyswietlanie  w trybie Preorder\n");
	Preorder(root_ptr);
	counter = 1;
	insert(&root_ptr,k2);
	counter = 1;
	printf("\nWyswietlanie  w trybie Inorder\n");
	Inorder(root_ptr);
	counter = 1;
	insert(&root_ptr,k3);
	insert(&root_ptr,k4);
	Del(&root_ptr, k1);
	printf("\nWyswietlanie  w trybie Preorder\n");
    Preorder(root_ptr);
	counter = 1;
	Find(root_ptr,k1);
	Del(&root_ptr,k2);
	printf("\nWyswietlanie  w trybie Inorder\n");
	Inorder(root_ptr);
	counter = 1;
	Del(&root_ptr,k3);
	Del(&root_ptr,k4);
	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC; 
	printf(" Time spent: %lf \n",time_spent);
	fclose(fp);
	free(root_ptr);
	system("PAUSE");
	return 0;
}

